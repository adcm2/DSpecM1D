#ifndef DSPECM1D_FULL_SPEC_MULTI_SEM_H
#define DSPECM1D_FULL_SPEC_MULTI_SEM_H

#include "FullSpec.h"
#include "EquilibratedSparseLU.h"

namespace SPARSESPEC {

inline Eigen::MatrixXcd
SparseFSpec::spectra(InputParametersNew &paramsNew) {
  auto &params = paramsNew.inputParameters();
  return spectra(paramsNew.freqFull(), paramsNew.earthModel(), paramsNew.cmt(),
                 params, paramsNew.nq(), paramsNew.srInfo(),
                 params.relative_error());
}

template <class model1d>
Eigen::MatrixXcd
SparseFSpec::spectra(SpectraSolver::FreqFull &myff, model1d &inp_model,
                     SourceInfo::EarthquakeCMT &cmt, InputParameters &params,
                     int NQ, SRInfo &srInfo, double relerr) {
  using Complex = std::complex<double>;
  using MatrixC = Eigen::MatrixXcd;
  using SparseMatrixC = Eigen::SparseMatrix<Complex>;
  using SparseLUType = EquilibratedSparseLU<Complex>;
  Timer timer1;

  if (params.attenuation())
    validateAttenuationReferencePeriod(inp_model.TREF());

  auto vecW = myff.w();
  SpecConstants sc(myff.ep(), inp_model.TREF());
  auto myi = sc.myi;
  auto ieps = sc.ieps;
  auto w0 = sc.w0;
  auto twopid = sc.twopid;

  auto numRec = params.num_receivers();
  int nskip = std::max(1, (myff.i2() - myff.i1()) / 20);
  auto iBegin = myff.i1();
  auto iEnd = myff.i2();   // one past last valid index
  if (iBegin < 0 || iEnd > static_cast<int>(vecW.size()) || iBegin >= iEnd) {
    throw std::runtime_error(
        "Invalid frequency index range in FullSpec_MultiSem.");
  }

  int numChunks = std::max(
      1, static_cast<int>(std::floor((myff.f22() - myff.f11()) / 10.0) + 1.0));

  std::vector<std::vector<double>> freqChunks(numChunks);
  std::vector<std::vector<int>> idxChunks(numChunks);

  double wl = vecW[iBegin];
  double wh = vecW[iEnd - 1];
  double wdiff = (wh - wl) / static_cast<double>(numChunks);

  int idxw = iBegin;
  for (int c = 0; c < numChunks; ++c) {
    double upper = (c == numChunks - 1) ? wh : (wl + wdiff * (c + 1));
    while (idxw < iEnd && vecW[idxw] <= upper) {
      freqChunks[c].push_back(vecW[idxw]);
      idxChunks[c].push_back(idxw);
      ++idxw;
    }
  }

  // Any stragglers (numeric edge cases) go to last chunk
  while (idxw < iEnd) {
    freqChunks.back().push_back(vecW[idxw]);
    idxChunks.back().push_back(idxw);
    ++idxw;
  }

  // Build maxSteps safely
  std::vector<double> maxSteps;
  maxSteps.reserve(numChunks);
  double baseLen = 0.78 * 1000 / inp_model.TimeNorm() * twopid;
  double newLen = std::pow(100.0 * relerr, 1.0 / (NQ - 1.0)) * baseLen;

  for (int c = 0; c < numChunks; ++c) {
    double fref = freqChunks[c].empty() ? wh : freqChunks[c].back();
    if (fref <= 0.0) {
      throw std::runtime_error("Non-positive reference frequency in chunking.");
    }
    double step = std::min(newLen / fref, 0.05);
    maxSteps.push_back(step);
  }

  MatrixC vecRaw = MatrixC::Zero(3 * params.num_receivers(), vecW.size());

  // std::cout << "Just before max step printout\n";
  for (auto s : maxSteps)
    std::cout << "Max step: " << s << "\n";
  // std::cout << "Just after max step printout\n\n";

  // build one SEM per chunk
  std::vector<Full1D::SEM> sems;
  for (int idx = 0; idx < numChunks; ++idx)
    sems.emplace_back(inp_model, maxSteps[idx], NQ, params.lmax(), cmt);

  timer1.start();
  SparseLUType solver, solver1;

  int lmin = params.lmin();
  int lmax = params.lmax();
  ParamRedInfo paramInfo(params, lmax);

  ModeFlags flags = resolveModeFlags(params.type(), lmin, lmax);
  bool inc_rad = flags.inc_rad;
  bool inc_tor = flags.inc_tor;
  bool inc_sph = flags.inc_sph;
  lmin = std::max(lmin, 1);

  // Validate each chunk's receiver support before entering any OpenMP region.
  std::vector<std::vector<int>> receiverElementsByChunk;
  receiverElementsByChunk.reserve(sems.size());
  for (const auto &sem : sems) {
    auto receiverElems = sem.receiverElements(params, inc_tor);
    receiverElementsByChunk.push_back(std::move(receiverElems));
  }

  // radials
  if (inc_rad) {
    timer1.start();
    for (int idxChunk = 0; idxChunk < numChunks; ++idxChunk) {
      Full1D::SEM &sem = sems[idxChunk];
      const auto &recElems = receiverElementsByChunk[idxChunk];
      auto lowidx = sem.ltgR(0, recElems[0], 0);
      auto upidx = sem.ltgR(1, recElems.back(), NQ - 1);
      int lenidx = upidx - lowidx + 1;
      SparseMatrixC keR = sem.hR().cast<Complex>();
      SparseMatrixC inR = sem.pR().cast<Complex>();
      SparseMatrixC keRAtten = sem.hRa().cast<Complex>();
      keR.makeCompressed();
      inR.makeCompressed();
      keRAtten.makeCompressed();
      MatrixC vecRedZ = sem.rvRedZR(params);
#pragma omp parallel default(shared) private(solver)
      {
#pragma omp for schedule(dynamic)
        for (int idx = 0; idx < (int) idxChunks[idxChunk].size(); ++idx) {
          double wval = freqChunks[idxChunk][idx];
          int idxw = idxChunks[idxChunk][idx];
          Complex w = wval + ieps;
          const Complex sourceAttenuation = params.attenuation()
                                                ? attenFactor(w, w0)
                                                : Complex(0.0, 0.0);
          auto source = sem.sourceTreatedRadial(cmt, w, sourceAttenuation);
          SparseMatrixC wR = -w * w * inR + keR;
          if (params.attenuation())
            wR += attenFactor(w, w0) * keRAtten;
          wR.makeCompressed();
          solver.compute(wR);
          MatrixC vecX = solver.solve(source.force);
          auto tmp = vecX.block(lowidx, 0, lenidx, 1);
          auto resval = (vecRedZ.transpose() * tmp).sum();
          MatrixC liftOutput = sem.sourceLiftReceiverRadial(
              params, source.lift, source.sourceElement);
          for (int idxr = 0; idxr < numRec; ++idxr) {
#pragma omp critical(torvecadd)
            {
              vecRaw(3 * idxr, idxw) += resval + liftOutput(3 * idxr, 0);
            }
          }
        }
      }
    }
    timer1.stop("Time for Radial Modes");
    std::cout << "\n";
  }

  // toroidals
  if (inc_tor) {
    std::cout << "Doing Toroidal Modes\n";
#pragma omp parallel default(shared) private(solver1)
    {
#pragma omp for schedule(dynamic)
      for (int idxl = lmin; idxl < lmax + 1; ++idxl) {
        MatrixC rvVals = srInfo.rvRedTor(idxl);
        for (int idxChunk = 0; idxChunk < numChunks; ++idxChunk) {
          Full1D::SEM &sem = sems[idxChunk];
          auto idxSource = sem.sourceElement(cmt);
          const auto &recElems = receiverElementsByChunk[idxChunk];
          // std::cout << "Debug 0\n";
          auto lowidx = sem.ltgT(recElems[0], 0);
          // std::cout << "Debug 1\n";
          auto upidx = sem.ltgT(recElems.back(), NQ - 1) + 1;
          // std::cout << "Debug 2\n";
          int lenidx = upidx - lowidx;
          auto lentor = sem.ltgT(sem.eu() - 1, NQ - 1) + 1;
          // std::cout << "Debug 3\n";

          SparseMatrixC hTor = sem.hTk(idxl).cast<Complex>();
          SparseMatrixC pTor = sem.pTk(idxl).cast<Complex>();
          SparseMatrixC hTorAtten = sem.hTa(idxl).cast<Complex>();
          hTor.makeCompressed();
          pTor.makeCompressed();
          hTorAtten.makeCompressed();

          // std::cout << "Debug 4\n";
          MatrixC fVals = sem.calculateForceRedCoefficientsT(cmt, idxl, 0.0);
          // std::cout << "Debug 5\n";
          MatrixC redC = rvVals * fVals;
          // std::cout << "Debug 6\n";
          MatrixC rvBase = sem.rvBaseFullT(params, idxl);
          // std::cout << "Debug 7\n";
          auto ridxtor = SpectralTools::allIndicesTor(
              sem, idxl, freqChunks[idxChunk], idxSource, nskip);
          auto i1 = idxChunks[idxChunk][0];
          auto lenChunk = freqChunks[idxChunk].size();
          MatrixC vecRawL = MatrixC::Zero(3 * params.num_receivers(), lenChunk);
          for (int idx = (int) lenChunk - 1; idx > -1; --idx) {
            auto wval = freqChunks[idxChunk][idx];
            Complex w = wval + ieps;
            const Complex sourceAttenuation = params.attenuation()
                                                  ? attenFactor(w, w0)
                                                  : Complex(0.0, 0.0);
            auto source = sem.sourceTreatedToroidal(
                cmt, idxl, w, sourceAttenuation);
            std::size_t ridx = ridxtor[idx];
            std::size_t len_ms = lentor - ridx;
            SparseMatrixC mat = hTor.block(ridx, ridx, len_ms, len_ms) -
                                w * w * pTor.block(ridx, ridx, len_ms, len_ms);
            if (params.attenuation())
              mat += attenFactor(w, w0) *
                     hTorAtten.block(ridx, ridx, len_ms, len_ms);
            mat.makeCompressed();
            auto fRed = source.force.block(ridx, 0, len_ms,
                                           source.force.cols());
            factorizeOrCompute(solver1, mat, (int) lenChunk - idx - 1, nskip);
            MatrixC vecSol = solver1.solve(fRed);
            auto lidx = lowidx - ridx;
            MatrixC receiverLift = sem.sourceLiftReceiverToroidal(
                params, idxl, source.lift, source.sourceElement);
            vecRawL.col(idx) +=
                redC.cwiseProduct(rvBase * vecSol.block(lidx, 0, lenidx, 2) +
                                  receiverLift)
                    .rowwise()
                    .sum();
          }
#pragma omp critical(torvecadd)
          {
            vecRaw.block(0, i1, 3 * params.num_receivers(), lenChunk) +=
                vecRawL;
          }
        }
      }
    }
  }

  // spheroidals
  if (inc_sph) {
    std::cout << "\nDoing Spheroidal Modes\n";
#pragma omp parallel default(shared) private(solver1)
    {
#pragma omp for schedule(dynamic)
      for (int idxl = lmin; idxl < lmax + 1; ++idxl) {
        MatrixC rvVals = srInfo.rvRedSph(idxl);
        for (int idxChunk = 0; idxChunk < numChunks; ++idxChunk) {
          Full1D::SEM &sem = sems[idxChunk];
          auto idxSource = sem.sourceElement(cmt);
          const auto &recElems = receiverElementsByChunk[idxChunk];
          MatrixC fVals = sem.calculateForceRedCoefficients(cmt, idxl, 0.0);
          MatrixC redC = rvVals * fVals;
          const int lenChunk = static_cast<int>(idxChunks[idxChunk].size());
          MatrixC vecRawL = MatrixC::Zero(3 * numRec, lenChunk);
          const double cutoffMhz = params.cowlingFrequencyMhz();
          int cowlingFirst = static_cast<int>(idxChunks[idxChunk].size());
          if (cutoffMhz > 0.0) {
            for (int idx = 0; idx < static_cast<int>(idxChunks[idxChunk].size());
                 ++idx) {
              const int globalIdx = idxChunks[idxChunk][idx];
              const double frequencyMhz =
                  myff.f(globalIdx) * 1000.0 / myff.timeNorm();
              if (frequencyMhz >= cutoffMhz) {
                cowlingFirst = idx;
                break;
              }
            }
          }

          // Each contiguous region owns its matrix layout and restarts the
          // truncation/factorization cadence at the region boundary.
          for (int region = 0; region < 2; ++region) {
            const bool useCowling = region == 1;
            const int regionBegin = useCowling ? cowlingFirst : 0;
            const int regionEnd = useCowling
                                      ? static_cast<int>(idxChunks[idxChunk].size())
                                      : cowlingFirst;
            if (regionBegin >= regionEnd)
              continue;

            const auto lowidx = useCowling
                                    ? sem.ltgSC(0, recElems[0], 0)
                                    : sem.ltgS(0, recElems[0], 0);
            const auto upidx = useCowling
                                   ? sem.ltgSC(1, recElems.back(), NQ - 1)
                                   : sem.ltgS(1, recElems.back(), NQ - 1);
            const int lenidx = upidx - lowidx + 1;
            const auto lensph = useCowling
                                    ? sem.ltgSC(1, sem.mesh().NE() - 1, NQ - 1) + 1
                                    : sem.ltgS(2, sem.mesh().NE() - 1, NQ - 1) + 1;
            SparseMatrixC pS =
                (useCowling ? sem.pSC(idxl) : sem.pS(idxl)).cast<Complex>();
            SparseMatrixC hS =
                (useCowling ? sem.hSC(idxl) : sem.hS(idxl)).cast<Complex>();
            SparseMatrixC hSa =
                (useCowling ? sem.hSCa(idxl) : sem.hSa(idxl)).cast<Complex>();
            pS.makeCompressed();
            hS.makeCompressed();
            hSa.makeCompressed();
            MatrixC rvBase = sem.rvBaseFull(params, idxl, useCowling);

            std::vector<double> regionW(freqChunks[idxChunk].begin() + regionBegin,
                                        freqChunks[idxChunk].begin() + regionEnd);
            auto ridxsph = SpectralTools::allIndicesSph(
                sem, idxl, regionW, idxSource, nskip, useCowling);
            SparseLUType regionSolver;
            for (int idx = regionEnd - 1; idx >= regionBegin; --idx) {
              const int localRegionIdx = idx - regionBegin;
              const double wval = freqChunks[idxChunk][idx];
              const std::size_t ridx = ridxsph[localRegionIdx];
              const std::size_t len_ms = lensph - ridx;
              const Complex w = wval + ieps;
              const Complex sourceAttenuation = params.attenuation()
                                                    ? attenFactor(w, w0)
                                                    : Complex(0.0, 0.0);
              auto source = sem.sourceTreatedSpheroidal(
                  cmt, idxl, w, sourceAttenuation, useCowling);
              SparseMatrixC wS = hS.block(ridx, ridx, len_ms, len_ms) -
                                 w * w * pS.block(ridx, ridx, len_ms, len_ms);
              if (params.attenuation())
                wS += attenFactor(w, w0) *
                      hSa.block(ridx, ridx, len_ms, len_ms);
              wS.makeCompressed();
              MatrixC fRed = source.force.block(ridx, 0, len_ms,
                                                source.force.cols());
              factorizeOrCompute(regionSolver, wS, regionEnd - idx - 1, nskip);
              MatrixC vecSol = regionSolver.solve(fRed);
              const auto lidx = lowidx - ridx;
              MatrixC receiverLift = sem.sourceLiftReceiver(
                  params, idxl, source.lift, source.sourceElement, useCowling);
              vecRawL.col(idx) +=
                  redC.cwiseProduct(rvBase * vecSol.block(lidx, 0, lenidx, 4) +
                                    receiverLift)
                      .rowwise()
                      .sum();
            }
          }
          if (lenChunk > 0) {
            const int i1 = idxChunks[idxChunk].front();
#pragma omp critical(torvecadd)
            {
              vecRaw.block(0, i1, 3 * numRec, lenChunk) += vecRawL;
            }
          }
        }
      }
    }
  }

  // backazimuth rotation
  for (int idxr = 0; idxr < params.num_receivers(); ++idxr) {
    auto baz = srInfo.backazimuths(idxr);
    auto sbaz = std::sin(baz), cbaz = std::cos(baz);
    for (int j = 0; j < vecRaw.cols(); ++j) {
      auto tmp1 = vecRaw(3 * idxr + 1, j);
      auto tmp2 = vecRaw(3 * idxr + 2, j);
      vecRaw(3 * idxr + 1, j) = -tmp1 * cbaz + tmp2 * sbaz;
      vecRaw(3 * idxr + 2, j) = tmp1 * sbaz + tmp2 * cbaz;
    }
  }

  // output factor
  for (int idxChunk = 0; idxChunk < numChunks; ++idxChunk) {
    for (int idx = 0; idx < (int) idxChunks[idxChunk].size(); ++idx) {
      auto wval = freqChunks[idxChunk][idx];
      auto idxw = idxChunks[idxChunk][idx];
      Complex w = wval + ieps;
      vecRaw.col(idxw) *= outputFactor(params.output_type(), w, myi);
    }
  }
  return vecRaw;
}

}   // namespace SPARSESPEC
#endif   // DSPECM1D_FULL_SPEC_MULTI_SEM_H
